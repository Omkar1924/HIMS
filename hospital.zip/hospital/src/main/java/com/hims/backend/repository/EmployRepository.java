package com.hims.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hims.backend.entity.Employ;

public interface EmployRepository extends JpaRepository<Employ, Long> {

    @Query("select e from Employ e order by e.id asc")
    List<Employ> findAllByOrderByIdAsc();
    
}
