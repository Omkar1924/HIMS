package com.hims.backend.entity;

import java.math.BigDecimal;
import java.util.*;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "patient_registration")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
public class PatientRegistration {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "patient_registration_id")
    private int patientRegistrationId;

    @Column(unique = true,nullable = false)
    private String uhid;

    private String salutation;
    private String firstName;
    private String middleName;
    private String lastName;
    private int age;
    private String ageUnit;

    @Column(unique = true)
    private String adharCardId;

    private String gender;
    private String dateOfBirth;
    private String maritalStatus;
    private String registrationDate;
    private String relation;
    private String relationName;
    private String religion;
    private String cast;
    private String occupation;
    private String qualification;
    private String motherName;
    private String address;
    @Column(name = "blood_group")
    private String areaVillage;
    private String cityDistrict;
    private String state;
    private String country;
    private String pinCode;
    private String mobileNumber;
    private String telNumberOff;
    private String telNumberRes;
    private String emailId;
    private String height;
    private String weight;
    private String sourceOfRegistration;
    private String remarks;
    private String previousHospital;
    private String referredContactNumber;
    private String nationality;
    private String incomeRange;
    private String contactNameInitial;
    private String contactName;
    private String contactRelation;
    private String telNumberRes1;
    private String telNumberOff1;
    private String contactNumber;
    private String isEmergency;
    private String erNo;
    private String gstin;
    private String pan;
    private String sponserType;
    private String eligibility;

    // @ManyToOne
    // private OrganisationMaster organisationMaster;

    private String policyNumber;
    private String policyStartDate;
    private String policyEndDate;

    @Lob
    @Column(name = "file_attachment",columnDefinition = "LONGBLOB")
    private byte[] fileAttachment;

    @ManyToMany
    @JoinTable(
            name = "patient_registration_doctor_mapping",
            joinColumns = @JoinColumn(name = "patientRegistrationId"),
            inverseJoinColumns = @JoinColumn(name = "add_doctor_id")
    )
    private List<AddDoctor> addDoctor = new ArrayList<>();

//    @OneToMany(mappedBy = "patient")
//    private List<Claim> claims;
//
//    @OneToMany(mappedBy = "patient")
//    private List<Insurance> insuranceList;

    public String xtra1;
    public String xtra2;
    public String xtra3;
    public String xtra4;
    public String xtra5;
    public String xtra6;
    public String xtra7;
    public String xtra8;
    public String xtra9;
    public String xtra10;

}
