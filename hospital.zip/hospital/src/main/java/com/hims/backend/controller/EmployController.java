package com.hims.backend.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.hims.backend.entity.Employ;
import com.hims.backend.services.EmployService;

@RestController
@RequestMapping("/api/employs")
@CrossOrigin(origins = "http://localhost:5173")
public class EmployController {

    private final EmployService service;

    public EmployController(EmployService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Employ create(@RequestBody Employ employ) {
        return service.create(employ);
    }

    @GetMapping
    public List<Employ> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public Employ getById(@PathVariable("id") Long id) {
        return service.getById(id);
    }

    @PutMapping("/{id}/role")
    public Employ updateRole(@PathVariable("id") Long id,
                             @RequestParam(name = "role") String role) {
        return service.updateRole(id, role);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable("id") Long id) {
        service.delete(id);
    }
}
