package com.hims.backend.services;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hims.backend.entity.Employ;
import com.hims.backend.repository.EmployRepository;

@Service
public class EmployService {

    private final EmployRepository repository;

    public EmployService(EmployRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public Employ create(Employ employ) {
        employ.setId(null);
        if (employ.getRole() == null || employ.getRole().isBlank()) {
            employ.setRole("NURSE");
        }
        return repository.save(employ);
    }

    public List<Employ> getAll() {
        return repository.findAllByOrderByIdAsc();
    }

    public Employ getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employ not found with id: " + id));
    }

    @Transactional
    public Employ updateRole(Long id, String newRole) {
        Employ employ = getById(id);
        employ.setRole(newRole);
        return repository.save(employ);
    }

    @Transactional
    public void delete(Long id) {
        repository.delete(getById(id));
    }
}
